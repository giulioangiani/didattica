package exthread00;

/**
 *
 * @author Giulio Angiani (IIS Pascal - Reggio Emilia)
 */
public class ThreadPari extends Thread implements Runnable {

    public ThreadPari() {
    }

    @Override
    public void run() {
        for (int i=0; i<30; i++) {
            Aspetta.wait(3);
            System.out.println("(PARI)  " + (i*2));
        }
    }
    
}
