package exthread00;

/**
 *
 * @author Giulio Angiani (IIS Pascal - Reggio Emilia)
 */
public class ThreadDispari extends Thread implements Runnable {

    public ThreadDispari() {
    }

    @Override
    public void run() {
        for (int i=0; i<30; i++) {
            Aspetta.wait(3);
            System.out.println("(DISPARI)  " + (i*2+1));
        }
    }
    
}
