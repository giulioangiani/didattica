package interfaces;

/**
 *
 * @author Giulio Angiani
 */
public interface Suonabile {
    public void emettisuono();
}
