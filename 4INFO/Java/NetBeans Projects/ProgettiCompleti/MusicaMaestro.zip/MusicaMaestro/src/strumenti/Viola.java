package strumenti;

import interfaces.Suonabile;

/**
 *
 * @author Giulio Angiani (IIS Pascal - Reggio Emilia)
 */
public class Viola implements Suonabile {

    @Override
    public void emettisuono() {
        System.out.println("Sono una viola faccio viiiiiiii");
    }

    
}
