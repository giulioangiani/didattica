package artisti;

import artisti.Musicista;

/**
 *
 * @author Giulio Angiani (IIS Pascal - Reggio Emilia)
 */
public class Pianista extends Musicista {

    public Pianista(String nome, String cognome) {
        super(nome, cognome);
    }
    
}
