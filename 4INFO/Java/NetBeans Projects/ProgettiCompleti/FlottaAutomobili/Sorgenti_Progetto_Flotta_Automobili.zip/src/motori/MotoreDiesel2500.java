package motori;

/**
 *
 * @author Giulio Angiani (IIS Pascal - Reggio Emilia)
 */
public class MotoreDiesel2500 extends MotoreDiesel {

    public MotoreDiesel2500(int rpm, int potenza) throws Exception {
        super(2500, rpm, potenza);
    }
    
}
