package errori;

/**
 *
 * @author Giulio Angiani (IIS Pascal - Reggio Emilia)
 */
public class RPM_not_valid_Exception extends FlottaAutomobiliGenericException {

    public RPM_not_valid_Exception() {
        super();
    }
    
}
