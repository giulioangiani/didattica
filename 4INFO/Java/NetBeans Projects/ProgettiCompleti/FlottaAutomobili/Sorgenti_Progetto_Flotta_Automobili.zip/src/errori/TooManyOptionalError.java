package errori;

/**
 *
 * @author Giulio Angiani (IIS Pascal - Reggio Emilia)
 */
public class TooManyOptionalError extends FlottaAutomobiliGenericException {

    public TooManyOptionalError() {
         super();
    }
}
