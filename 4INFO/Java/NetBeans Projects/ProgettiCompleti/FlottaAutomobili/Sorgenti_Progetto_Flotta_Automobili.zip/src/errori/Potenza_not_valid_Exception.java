package errori;

/**
 *
 * @author Giulio Angiani (IIS Pascal - Reggio Emilia)
 */
public class Potenza_not_valid_Exception extends FlottaAutomobiliGenericException {

    public Potenza_not_valid_Exception() {
         super();
    }
    
}
