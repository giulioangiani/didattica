package errori;

/**
 *
 * @author Giulio Angiani (IIS Pascal - Reggio Emilia)
 */
public class Cilindrata_not_valid_Exception extends FlottaAutomobiliGenericException {

    public Cilindrata_not_valid_Exception() {
         super();
    }
    
}
