package exthread00;

/**
 *
 * @author Giulio Angiani (IIS Pascal - Reggio Emilia)
 */
public class ThreadPari implements Runnable {
    // devi implementare il metodo di Runnable...

    public ThreadPari() {
    }
    
}
