package exthread00;

/**
 *
 * @author Giulio Angiani (IIS Pascal - Reggio Emilia)
 */
public class ThreadDispari implements Runnable {
    // devi implementare il metodo di Runnable...

    public ThreadDispari() {
    }
    
}
